import { DefaultTheme } from 'styled-components';

const MyTheme = {
	green2: '#2f7a5c',
	green3: '#35b281',
	green4: '#26805c',
	green5: '#28664D',
};

/* green darker variations
'#3fa27b'
'#378e6c'
'#2f7a5c'
'#28664D'
'#20513e'
*/

let x = '#20513e';
let y = foo('#20513e');

export default myTheme;
